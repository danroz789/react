
export default function AboutPage() {
    return (
        <div>AboutPage</div>
    )
}
