export default function CreateMultipleQuesiton() {
    return (
        <div>CreateMultipleQuesiton</div>
    )
}
